AdvancedMapReduceFramework
==========================

A Map Reduce Framework from Scratch
